Senior Seminar II research snapshot, November 20, 2026

From this directory run: python3 -m scripts.verify_research_snapshot
Table reconstruction uses the Python standard library and bundled code.
For independent rescoring and policy replay, install requirements.txt in a virtual
environment, then run: python -m scripts.verify_research_snapshot --rescore
Both checks run offline. No API keys or new model runs are required.
See docs/RESEARCH_COMPLETION.md for the scope and remaining research questions.
