"""Thin wrapper around the Gemini API.

Adds the three things the evaluation harness needs that the raw SDK does not
give us: a process-wide rate limiter (Gemini free tier is a few requests per
minute), retry with exponential backoff on 429/503, and a call counter so the
report can state how many real API calls were made.
"""
from __future__ import annotations

import os
import random
import re
import threading
import time
from dataclasses import dataclass, field

from dotenv import load_dotenv

load_dotenv()

PROVIDER = os.environ.get("LLM_PROVIDER", "gemini")
if PROVIDER not in {"gemini", "groq"}:
    raise ValueError("LLM_PROVIDER must be gemini or groq")
DEFAULT_MODEL = os.environ.get("GROQ_MODEL", "openai/gpt-oss-20b") if PROVIDER == "groq" else os.environ.get("GEMINI_MODEL", "gemini-3.6-flash")
DEFAULT_JUDGE_MODEL = os.environ.get("GROQ_JUDGE_MODEL" if PROVIDER == "groq" else "GEMINI_JUDGE_MODEL", DEFAULT_MODEL)

# Requests per minute to allow across all threads. Override with GEMINI_RPM.
RPM = int(os.environ.get("GROQ_RPM" if PROVIDER == "groq" else "GEMINI_RPM", "5"))

# Gemini 3.x "thinking" is on by default and can consume the whole output budget
# (and ~13s of latency) before any answer text appears. A small fixed budget keeps
# replies fast and well-formed; set GEMINI_THINKING_BUDGET=-1 for dynamic thinking.
THINKING_BUDGET = int(os.environ.get("GEMINI_THINKING_BUDGET", "0"))


def redact_secrets(text):
    for name in ("GEMINI_API_KEY", "GROQ_API_KEY"):
        key = os.environ.get(name)
        if key: text = text.replace(key, "[REDACTED]")
    return text


class LLMError(RuntimeError):
    pass


@dataclass
class _Stats:
    calls: int = 0
    retries: int = 0
    failures: int = 0
    total_latency_s: float = 0.0
    lock: threading.Lock = field(default_factory=threading.Lock)

    def record(self, latency: float) -> None:
        with self.lock:
            self.calls += 1
            self.total_latency_s += latency

    def snapshot(self) -> dict:
        with self.lock:
            return {
                "calls": self.calls,
                "retries": self.retries,
                "failures": self.failures,
                "total_latency_s": round(self.total_latency_s, 2),
                "mean_latency_s": round(self.total_latency_s / self.calls, 3) if self.calls else 0.0,
            }


STATS = _Stats()


class _RateLimiter:
    """Simple spacing limiter: guarantees >= (60 / rpm) seconds between starts."""

    def __init__(self, rpm: int) -> None:
        self._min_interval = 60.0 / max(rpm, 1)
        self._lock = threading.Lock()
        self._next_allowed = 0.0

    def acquire(self) -> None:
        with self._lock:
            now = time.monotonic()
            wait = max(0.0, self._next_allowed - now)
            self._next_allowed = max(now, self._next_allowed) + self._min_interval
        if wait > 0:
            time.sleep(wait)


_LIMITER = _RateLimiter(RPM)
_client = None
_client_lock = threading.Lock()


def get_client():
    """Lazily build the shared genai client so importing this module is cheap."""
    global _client
    if _client is None:
        with _client_lock:
            if _client is None:
                api_key = os.environ.get("GEMINI_API_KEY")
                if not api_key:
                    raise LLMError(
                        "GEMINI_API_KEY is not set. Copy .env.example to .env and paste your key."
                    )
                from google import genai

                _client = genai.Client(api_key=api_key, http_options={"timeout": 60000})
    return _client


def _is_retryable(exc: Exception) -> bool:
    text = f"{type(exc).__name__}: {exc}".lower()
    return any(
        marker in text
        for marker in (
            "429", "resource_exhausted", "rate limit", "quota",
            "503", "unavailable", "500", "internal", "deadline", "timeout",
        )
    )


def retry_delay(exc: Exception, attempt: int) -> float:
    """Honor the provider retry hint, with a bounded wait and fallback backoff."""
    message = str(exc)
    match = re.search(r"retry in ([0-9.]+)s", message, re.IGNORECASE)
    if not match:
        match = re.search(r"retryDelay['\"]?\s*:\s*['\"]([0-9.]+)s", message)
    if match:
        return min(60.0, float(match.group(1)) + 1.0)
    return min(2**attempt + random.uniform(0, 1.0), 60.0)


def generate(
    prompt: str,
    *,
    system_instruction: str | None = None,
    model: str | None = None,
    temperature: float = 0.0,
    max_output_tokens: int = 1024,
    max_attempts: int = 3,
) -> str:
    """Single-turn text generation. Returns the model's text, or raises LLMError."""
    if PROVIDER == "groq":
        from agent.groq_provider import complete
        _LIMITER.acquire()
        started = time.monotonic()
        try:
            text = complete(prompt, system_instruction=system_instruction, model=model or DEFAULT_MODEL,
                            temperature=temperature, max_output_tokens=max_output_tokens)
            STATS.record(time.monotonic() - started)
            return text
        except Exception as exc:
            with STATS.lock:
                STATS.failures += 1
            raise LLMError(redact_secrets(str(exc))) from None
    from google.genai import types

    client = get_client()
    model = model or DEFAULT_MODEL
    # Use budget control only on the model family that supports it.
    thinking = types.ThinkingConfig(thinking_budget=THINKING_BUDGET) if model.startswith("gemini-2.5-") else None
    config = types.GenerateContentConfig(
        temperature=temperature,
        max_output_tokens=max_output_tokens,
        system_instruction=system_instruction,
        thinking_config=thinking,
        # Injection payloads routinely trip the default safety filters, which would
        # silently turn an *unsuccessful* attack into an API error. Disable them so
        # that what we measure is the agent's behaviour, not Google's moderation.
        safety_settings=[
            types.SafetySetting(category=c, threshold="BLOCK_NONE")
            for c in (
                "HARM_CATEGORY_HARASSMENT",
                "HARM_CATEGORY_HATE_SPEECH",
                "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                "HARM_CATEGORY_DANGEROUS_CONTENT",
            )
        ],
    )

    last_exc: Exception | None = None
    for attempt in range(max_attempts):
        _LIMITER.acquire()
        start = time.monotonic()
        try:
            resp = client.models.generate_content(model=model, contents=prompt, config=config)
            STATS.record(time.monotonic() - start)
            text = (resp.text or "").strip()
            if not text:
                # Empty completion (e.g. recitation / MAX_TOKENS with no text).
                # Treat as a non-answer rather than crashing the run.
                return ""
            return text
        except Exception as exc:  # noqa: BLE001 - SDK raises many concrete types
            last_exc = exc
            if not _is_retryable(exc) or attempt == max_attempts - 1:
                break
            with STATS.lock:
                STATS.retries += 1
            delay = retry_delay(exc, attempt)
            time.sleep(delay)

    with STATS.lock:
        STATS.failures += 1
    detail = str(last_exc).replace(os.environ.get("GEMINI_API_KEY") or "__NO_KEY__", "[REDACTED]")
    raise LLMError(f"Gemini call failed after {attempt + 1} attempts: {detail}")
